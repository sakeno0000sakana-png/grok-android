# Android アプリ化

このプロジェクトは React / TanStack Start 製です。Android 版は Capacitor を使ってネイティブ WebView アプリとしてパッケージします。

## 必要な環境
- Node.js 20 以上
- Android Studio（Android SDK / Build Tools を含む）
- JDK 21

## セットアップ

```bash
npm install
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio で `Build > Build Bundle(s) / APK(s) > Build APK(s)` を選ぶと APK を生成できます。

## 注意
このアプリは3Dモデル表示を含むため、Android 端末では WebGL が有効な WebView が必要です。Android Studio の実機またはエミュレータで、3D表示・ドラッグ回転・ピンチズーム・GLB保存を確認してください。

TanStack Start のサーバー機能に依存する機能が追加されている場合は、静的アセットだけでは動作しないため、API サーバーの配置が別途必要です。
