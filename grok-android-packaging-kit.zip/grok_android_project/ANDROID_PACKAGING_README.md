# Android パッケージング用プロジェクト

このZIPは、元の「雪白 Studio Figure」React/TanStack Start プロジェクトに Capacitor の Android 化設定を加えたソース一式です。APKそのものや、汎用の「URLを入力するだけ」の包装アプリに直接読み込ませるHTML一式ではありません。

## Android Studio / Capacitor でAPKにする場合

必要: Node.js 20+、JDK 21、Android Studio / Android SDK。

```bash
npm ci
npm install @capacitor/android
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

Android Studioで `Build > Build Bundle(s) / APK(s) > Build APK(s)` を選択します。

## 注意事項

- このアプリは TanStack Start のサーバー機能を利用します。`.output/public` だけを静的ホスティングする方式や、HTMLファイルを包むだけの一般的なWeb-to-APKサービスでは、サーバー依存機能が動かない可能性があります。
- その場合は、アプリ本体を対応するNode.jsサーバー環境（例: Vercel等）へ先にデプロイし、URLをWebViewラッパーに設定する方式が必要です。
- 3D表示はAndroid WebViewのWebGL対応が必要です。実機で回転・ズーム・保存を確認してください。
- `appId`: `jp.studiofigure.app`
- `appName`: `雪白 Studio Figure`
