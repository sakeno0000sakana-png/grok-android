import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'jp.studiofigure.app',
  appName: '雪白 Studio Figure',
  webDir: '.output/public',
  bundledWebRuntime: false,
  android: {
    allowMixedContent: false,
    backgroundColor: '#f4f1eb',
  },
};

export default config;
