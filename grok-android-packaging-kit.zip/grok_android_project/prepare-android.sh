#!/usr/bin/env bash
set -euo pipefail

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 20+ が必要です" >&2; exit 1
fi
node -e 'const v=process.versions.node.split(".").map(Number); if(v[0]<20) process.exit(1)' || { echo "Node.js 20+ が必要です" >&2; exit 1; }

npm ci
npm install @capacitor/android
if [ ! -d android ]; then
  npx cap add android
fi
npm run build
npx cap sync android
printf '\n完了: Android Studioで android/ を開き、Build > Build Bundle(s) / APK(s) > Build APK(s) を実行してください。\n'
