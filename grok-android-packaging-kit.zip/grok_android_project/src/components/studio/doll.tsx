import {
  createContext,
  forwardRef,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  type Ref,
} from "react";
import { useFrame } from "@react-three/fiber";
import { RoundedBox } from "@react-three/drei";
import * as THREE from "three";

type Vec3 = readonly [number, number, number];

type Surface = {
  color: string;
  roughness?: number;
  metalness?: number;
  clearcoat?: number;
  sheen?: number;
  sheenColor?: string;
  double?: boolean;
  basic?: boolean;
  opacity?: number;
  toneMapped?: boolean;
};

const SURFACE = {
  skin: {
    color: "#f4ddd4",
    roughness: 0.46,
    sheen: 0.42,
    sheenColor: "#ffd0c6",
    clearcoat: 0.08,
  },
  hair: {
    color: "#efeae2",
    roughness: 0.52,
    metalness: 0.04,
    sheen: 0.7,
    sheenColor: "#ffffff",
  },
  hairDeep: {
    color: "#ddd4ca",
    roughness: 0.58,
    sheen: 0.45,
    sheenColor: "#f4efe8",
  },
  hoodie: { color: "#f3eee6", roughness: 0.92, sheen: 0.18, sheenColor: "#fffaf4", double: true },
  shirt: { color: "#f7f7f5", roughness: 0.78 },
  shorts: { color: "#c3beb6", roughness: 0.9 },
  shortsBand: { color: "#b3aea6", roughness: 0.86 },
  knit: { color: "#f7f3ed", roughness: 0.96 },
  cuff: { color: "#e6dfd6", roughness: 0.9 },
  shoe: { color: "#f6f4f1", roughness: 0.42, clearcoat: 0.28 },
  lace: { color: "#f3f0eb", roughness: 0.55 },
  ribbon: { color: "#f7f2eb", roughness: 0.62, double: true },
  metal: { color: "#d8d9dd", roughness: 0.25, metalness: 0.88 },
  lip: { color: "#e4aaa4", roughness: 0.38, sheen: 0.45, sheenColor: "#ffd4ce" },
  brow: { color: "#c9beb2", roughness: 0.55 },
  iris: { color: "#7b5b39", roughness: 0.16, clearcoat: 0.95, metalness: 0.06 },
  sclera: { color: "#f6f4f2", roughness: 0.22, clearcoat: 0.35 },
  lash: { basic: true, color: "#2b2724" },
  pupil: { basic: true, color: "#16120f" },
  catch: { basic: true, color: "#ffffff", toneMapped: false },
  blush: { basic: true, color: "#e7a396", opacity: 0.38 },
  mark: { color: "#f4f0ea", roughness: 0.45 },
} satisfies Record<string, Surface>;

type Kind = keyof typeof SURFACE;

const FigureContext = createContext({ wire: false, alive: true });

function Mat({ kind, map }: { kind: Kind; map?: THREE.Texture | null }) {
  const { wire } = useContext(FigureContext);
  const s = SURFACE[kind] as Surface;
  if (s.basic) {
    return (
      <meshBasicMaterial
        color={wire ? "#2a2826" : s.color}
        wireframe={wire}
        transparent={s.opacity != null && s.opacity < 1}
        opacity={s.opacity ?? 1}
        depthWrite={s.opacity == null || s.opacity >= 1}
        toneMapped={s.toneMapped ?? true}
      />
    );
  }
  return (
    <meshPhysicalMaterial
      color={wire ? "#2a2826" : s.color}
      map={map ?? undefined}
      roughness={s.roughness ?? 0.6}
      metalness={s.metalness ?? 0}
      clearcoat={s.clearcoat ?? 0}
      clearcoatRoughness={0.5}
      sheen={s.sheen ?? 0}
      sheenColor={s.sheenColor ?? "#ffffff"}
      sheenRoughness={0.55}
      wireframe={wire}
      side={s.double ? THREE.DoubleSide : THREE.FrontSide}
    />
  );
}

function orient(a: Vec3, b: Vec3) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const dz = b[2] - a[2];
  const length = Math.hypot(dx, dy, dz) || 0.0001;
  const position = new THREE.Vector3((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2);
  const quaternion = new THREE.Quaternion().setFromUnitVectors(
    new THREE.Vector3(0, 1, 0),
    new THREE.Vector3(dx / length, dy / length, dz / length),
  );
  return { position, quaternion, length };
}

function Limb({
  a,
  b,
  radius,
  kind,
  name,
  detail = "low",
}: {
  a: Vec3;
  b: Vec3;
  radius: number;
  kind: Kind;
  name?: string;
  detail?: "low" | "high";
}) {
  const { position, quaternion, length } = orient(a, b);
  const cyl = Math.max(0.001, length - radius * 2);
  const cap = detail === "high" ? 6 : 3;
  const radial = detail === "high" ? 14 : 8;
  return (
    <mesh name={name} position={position} quaternion={quaternion}>
      <capsuleGeometry args={[radius, cyl, cap, radial]} />
      <Mat kind={kind} />
    </mesh>
  );
}

function makeTube(pts: readonly Vec3[], radius: number) {
  const curve = new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(p[0], p[1], p[2])));
  return new THREE.TubeGeometry(curve, 28, radius, 5, false);
}

const CHAIN = makeTube(
  [
    [-0.034, 1.35, 0.06],
    [0, 1.205, 0.132],
    [0.034, 1.35, 0.06],
  ],
  0.0032,
);
const DRAW_A = makeTube(
  [
    [0.012, 0.945, 0.11],
    [0.02, 0.84, 0.125],
    [0.01, 0.74, 0.112],
  ],
  0.0036,
);
const DRAW_B = makeTube(
  [
    [-0.006, 0.945, 0.11],
    [-0.016, 0.82, 0.122],
    [-0.004, 0.73, 0.108],
  ],
  0.0036,
);
const RIBBONS = [
  makeTube(
    [
      [-0.1, 1.44, 0.11],
      [-0.18, 1.02, 0.05],
      [-0.12, 0.52, 0.04],
    ],
    0.0065,
  ),
  makeTube(
    [
      [-0.08, 1.42, 0.13],
      [-0.02, 0.95, 0.15],
      [0.02, 0.46, 0.08],
    ],
    0.0055,
  ),
  makeTube(
    [
      [0.22, 0.8, 0.07],
      [0.3, 0.55, 0.04],
      [0.18, 0.3, 0.03],
    ],
    0.0062,
  ),
  makeTube(
    [
      [0.18, 0.82, 0.08],
      [0.1, 0.5, 0.12],
      [0.16, 0.28, 0.05],
    ],
    0.0052,
  ),
  makeTube(
    [
      [-0.16, 0.98, 0.04],
      [-0.22, 0.68, 0.02],
      [-0.12, 0.4, 0.02],
    ],
    0.006,
  ),
  makeTube(
    [
      [0.16, 0.96, 0.06],
      [0.22, 0.66, 0.04],
      [0.12, 0.38, 0.03],
    ],
    0.006,
  ),
];

const HAIR: readonly (readonly [Vec3, Vec3, number, Kind])[] = [
  [[0, 0.05, -0.01], [0.01, 0.16, 0.02], 0.052, "hair"],
  [[-0.05, 0.07, -0.01], [-0.09, 0.15, 0.03], 0.038, "hair"],
  [[0.05, 0.06, 0], [0.1, 0.145, 0.02], 0.036, "hair"],
  [[-0.01, 0.16, 0.01], [-0.05, 0.2, 0.03], 0.014, "hair"],
  [[0.04, 0.14, 0], [0.1, 0.185, 0.02], 0.012, "hair"],
  [[0, 0.13, -0.03], [0.02, 0.2, -0.01], 0.013, "hair"],
  [[-0.02, 0.11, 0.05], [-0.04, 0.02, 0.125], 0.03, "hair"],
  [[0.035, 0.11, 0.04], [0.03, 0.03, 0.13], 0.026, "hair"],
  [[-0.07, 0.09, 0.04], [-0.105, 0.0, 0.095], 0.028, "hair"],
  [[-0.035, 0.08, 0.075], [-0.055, -0.025, 0.12], 0.02, "hair"],
  [[-0.1, 0.04, 0.01], [-0.14, -0.08, 0.03], 0.036, "hair"],
  [[0.1, 0.05, 0.01], [0.135, -0.055, 0.04], 0.034, "hair"],
  [[0, 0.04, -0.06], [0, -0.1, -0.1], 0.052, "hairDeep"],
  [[-0.07, 0.03, -0.05], [-0.105, -0.09, -0.045], 0.04, "hairDeep"],
  [[0.07, 0.03, -0.05], [0.11, -0.08, -0.04], 0.038, "hairDeep"],
  [[-0.09, 0.0, 0.045], [-0.115, -0.06, 0.07], 0.024, "hair"],
  [[0.09, 0.01, 0.05], [0.115, -0.04, 0.075], 0.022, "hair"],
];

const SH_R: Vec3 = [-0.2, 1.29, 0.02];
const EL_R: Vec3 = [-0.31, 1.5, 0.055];
const CUFF_R: Vec3 = [-0.1, 1.45, 0.105];
const PALM_R: Vec3 = [-0.05, 1.468, 0.128];
const SH_L: Vec3 = [0.2, 1.28, 0];
const EL_L: Vec3 = [0.29, 1.02, 0.03];
const CUFF_L: Vec3 = [0.22, 0.82, 0.055];
const HIP_L: Vec3 = [0.074, 0.8, 0.012];
const HIP_R: Vec3 = [-0.074, 0.8, 0.012];
const KNEE_L: Vec3 = [0.072, 0.46, 0.03];
const KNEE_R: Vec3 = [-0.072, 0.46, 0.03];
const ANK_L: Vec3 = [0.07, 0.17, 0.02];
const ANK_R: Vec3 = [-0.07, 0.17, 0.02];

function useRibMap() {
  const map = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 32;
    canvas.height = 64;
    const g = canvas.getContext("2d");
    if (!g) return null;
    g.fillStyle = "#f7f3ed";
    g.fillRect(0, 0, 32, 64);
    g.strokeStyle = "#e3dbd1";
    g.lineWidth = 2;
    for (let x = 1; x < 32; x += 3) {
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x, 64);
      g.stroke();
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(6, 1);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);
  useEffect(() => () => map?.dispose(), [map]);
  return map;
}

function Eye({ x }: { x: number }) {
  const ref = useRef<THREE.Group>(null);
  const { alive } = useContext(FigureContext);
  const aliveRef = useRef(alive);
  aliveRef.current = alive;
  useFrame((state) => {
    const g = ref.current;
    if (!g) return;
    if (!aliveRef.current) {
      g.scale.y = 1;
      return;
    }
    const t = state.clock.elapsedTime;
    let closed = 0;
    if (t > 2.2) {
      const phase = t % 4.2;
      if (phase > 3.92) closed = Math.sin(((phase - 3.92) / 0.28) * Math.PI);
    }
    g.scale.y = 1 - closed * 0.9;
  });
  return (
    <group ref={ref} position={[x, 0.012, 0.1]}>
      <mesh scale={[1, 0.78, 0.42]}>
        <sphereGeometry args={[0.033, 18, 14]} />
        <Mat kind="sclera" />
      </mesh>
      <mesh position={[0, -0.002, 0.016]} scale={[1, 1, 0.5]}>
        <sphereGeometry args={[0.018, 18, 14]} />
        <Mat kind="iris" />
      </mesh>
      <mesh position={[0, -0.002, 0.024]}>
        <sphereGeometry args={[0.009, 12, 10]} />
        <Mat kind="pupil" />
      </mesh>
      <mesh position={[0.007, 0.006, 0.03]}>
        <sphereGeometry args={[0.0042, 8, 8]} />
        <Mat kind="catch" />
      </mesh>
      <mesh position={[-0.005, -0.004, 0.028]}>
        <sphereGeometry args={[0.002, 8, 8]} />
        <Mat kind="catch" />
      </mesh>
      <mesh position={[0, 0.02, 0.008]} rotation={[0.4, 0, x > 0 ? -0.08 : 0.1]} scale={[1.12, 0.5, 0.5]}>
        <sphereGeometry args={[0.034, 14, 10]} />
        <Mat kind="skin" />
      </mesh>
      <mesh position={[0, 0.022, 0.026]} rotation={[0.15, 0, x > 0 ? -0.1 : 0.14]}>
        <boxGeometry args={[0.054, 0.005, 0.007]} />
        <Mat kind="lash" />
      </mesh>
    </group>
  );
}

function Bow({ position }: { position: Vec3 }) {
  return (
    <group position={position}>
      <mesh rotation={[0.2, 0.45, 0.45]}>
        <torusGeometry args={[0.028, 0.007, 6, 10, Math.PI * 1.2]} />
        <Mat kind="ribbon" />
      </mesh>
      <mesh rotation={[0.2, -0.45, -0.45]} scale={[-1, 1, 1]}>
        <torusGeometry args={[0.028, 0.007, 6, 10, Math.PI * 1.2]} />
        <Mat kind="ribbon" />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.011, 10, 8]} />
        <Mat kind="ribbon" />
      </mesh>
    </group>
  );
}

function Cuff({ at, from, radius }: { at: Vec3; from: Vec3; radius: number }) {
  const { quaternion } = orient(from, at);
  return (
    <group position={at} quaternion={quaternion}>
      {[0, 1, 2, 3].map((i) => (
        <mesh key={i} position={[0, -i * 0.014, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[radius, 0.01, 6, 14]} />
          <Mat kind="cuff" />
        </mesh>
      ))}
    </group>
  );
}

function Head() {
  const hair = useRef<THREE.Group>(null);
  const { alive } = useContext(FigureContext);
  const aliveRef = useRef(alive);
  aliveRef.current = alive;
  useFrame((state) => {
    const g = hair.current;
    if (!g) return;
    if (!aliveRef.current) {
      g.rotation.z = 0;
      g.rotation.x = 0;
      return;
    }
    const t = state.clock.elapsedTime;
    g.rotation.z = Math.sin(t * 0.9) * 0.012;
    g.rotation.x = Math.sin(t * 0.7) * 0.008;
  });
  return (
    <group position={[0, 1.52, 0]} name="head">
      <mesh scale={[0.126, 0.136, 0.118]} name="cranium">
        <sphereGeometry args={[1, 32, 24]} />
        <Mat kind="skin" />
      </mesh>
      <mesh position={[0, -0.048, 0.018]} scale={[0.106, 0.076, 0.094]} name="jaw">
        <sphereGeometry args={[1, 24, 18]} />
        <Mat kind="skin" />
      </mesh>
      {([-1, 1] as const).map((side) => (
        <mesh key={side} position={[side * 0.112, -0.01, 0]} scale={[0.4, 0.62, 0.36]}>
          <sphereGeometry args={[0.042, 12, 10]} />
          <Mat kind="skin" />
        </mesh>
      ))}
      <mesh position={[0, -0.012, 0.112]} scale={[0.65, 0.75, 0.6]}>
        <sphereGeometry args={[0.014, 12, 10]} />
        <Mat kind="skin" />
      </mesh>
      <mesh position={[0, -0.054, 0.108]} rotation={[0.25, 0, 0]} scale={[1, 0.42, 0.5]}>
        <sphereGeometry args={[0.016, 16, 12]} />
        <Mat kind="lip" />
      </mesh>
      <Eye x={-0.046} />
      <Eye x={0.046} />
      <Limb a={[-0.078, 0.055, 0.095]} b={[-0.02, 0.064, 0.112]} radius={0.005} kind="brow" />
      <Limb a={[0.02, 0.064, 0.112]} b={[0.078, 0.05, 0.095]} radius={0.005} kind="brow" />
      {([-1, 1] as const).map((side) => (
        <mesh key={side} position={[side * 0.07, -0.02, 0.09]} scale={[0.034, 0.02, 0.012]} renderOrder={2}>
          <sphereGeometry args={[1, 12, 10]} />
          <Mat kind="blush" />
        </mesh>
      ))}
      <group ref={hair} name="hair">
        <mesh position={[0, 0.03, -0.028]} scale={[0.142, 0.148, 0.118]} name="scalp">
          <sphereGeometry args={[1, 28, 20]} />
          <Mat kind="hair" />
        </mesh>
        {HAIR.map(([a, b, radius, kind], i) => (
          <Limb key={i} a={a} b={b} radius={radius} kind={kind} />
        ))}
        <group position={[0.098, 0.09, 0.05]} rotation={[0.25, 0.3, 0.15]} name="hair-clip">
          <mesh rotation={[0, 0, Math.PI / 4]}>
            <boxGeometry args={[0.042, 0.007, 0.007]} />
            <Mat kind="mark" />
          </mesh>
          <mesh rotation={[0, 0, -Math.PI / 4]}>
            <boxGeometry args={[0.042, 0.007, 0.007]} />
            <Mat kind="mark" />
          </mesh>
        </group>
      </group>
    </group>
  );
}

function Torso() {
  return (
    <group name="torso">
      <Limb a={[0, 0.98, 0.01]} b={[0, 1.34, 0.02]} radius={0.092} kind="skin" detail="high" name="body" />
      <mesh position={[0, 1.4, 0.015]} name="neck">
        <cylinderGeometry args={[0.04, 0.05, 0.1, 16]} />
        <Mat kind="skin" />
      </mesh>
      <mesh position={[0, 1.175, 0.045]} scale={[0.148, 0.135, 0.108]} name="shirt">
        <sphereGeometry args={[1, 24, 18]} />
        <Mat kind="shirt" />
      </mesh>
      <mesh position={[0, 1.055, 0.05]} rotation={[0.18, 0, 0]}>
        <torusGeometry args={[0.108, 0.01, 8, 18]} />
        <Mat kind="shirt" />
      </mesh>
    </group>
  );
}

function Hoodie() {
  return (
    <group name="hoodie">
      <RoundedBox args={[0.38, 0.56, 0.09]} radius={0.03} smoothness={4} position={[0, 1.02, -0.09]}>
        <Mat kind="hoodie" />
      </RoundedBox>
      <RoundedBox args={[0.07, 0.48, 0.15]} radius={0.02} smoothness={3} position={[-0.175, 1.02, -0.01]}>
        <Mat kind="hoodie" />
      </RoundedBox>
      <RoundedBox args={[0.07, 0.48, 0.15]} radius={0.02} smoothness={3} position={[0.175, 1.02, -0.01]}>
        <Mat kind="hoodie" />
      </RoundedBox>
      <group position={[0.135, 0.99, 0.095]} rotation={[0.05, -0.75, 0.06]}>
        <RoundedBox args={[0.15, 0.44, 0.03]} radius={0.012} smoothness={2}>
          <Mat kind="hoodie" />
        </RoundedBox>
      </group>
      <group position={[-0.145, 1.04, 0.07]} rotation={[0.1, 0.9, -0.12]}>
        <RoundedBox args={[0.14, 0.34, 0.03]} radius={0.012} smoothness={2}>
          <Mat kind="hoodie" />
        </RoundedBox>
      </group>
      <mesh position={[0, 1.36, -0.06]} rotation={[0.35, 0, 0]} name="hood">
        <sphereGeometry args={[0.13, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.5]} />
        <Mat kind="hoodie" />
      </mesh>
      <mesh position={SH_R}>
        <sphereGeometry args={[0.09, 16, 12]} />
        <Mat kind="hoodie" />
      </mesh>
      <mesh position={SH_L}>
        <sphereGeometry args={[0.088, 16, 12]} />
        <Mat kind="hoodie" />
      </mesh>
      <Limb a={SH_R} b={EL_R} radius={0.078} kind="hoodie" detail="high" name="sleeve-r" />
      <Limb a={EL_R} b={CUFF_R} radius={0.06} kind="hoodie" detail="high" />
      <Limb a={SH_L} b={EL_L} radius={0.074} kind="hoodie" detail="high" name="sleeve-l" />
      <Limb a={EL_L} b={CUFF_L} radius={0.058} kind="hoodie" detail="high" />
      <Cuff at={CUFF_R} from={EL_R} radius={0.055} />
      <Cuff at={CUFF_L} from={EL_L} radius={0.052} />
      <Bow position={[-0.24, 1.34, 0.08]} />
      <Bow position={[0.27, 1.1, 0.05]} />
    </group>
  );
}

function Hands() {
  return (
    <group name="hands">
      <Limb a={CUFF_R} b={PALM_R} radius={0.02} kind="skin" />
      <mesh position={PALM_R} scale={[0.85, 1.05, 0.65]}>
        <sphereGeometry args={[0.026, 14, 12]} />
        <Mat kind="skin" />
      </mesh>
      <Limb a={[-0.032, 1.462, 0.138]} b={[-0.01, 1.45, 0.15]} radius={0.008} kind="skin" />
      <Limb a={[-0.01, 1.45, 0.15]} b={[0.008, 1.442, 0.158]} radius={0.007} kind="skin" />
      <Limb a={[-0.04, 1.455, 0.122]} b={[-0.02, 1.432, 0.132]} radius={0.0075} kind="skin" />
      <Limb a={[-0.02, 1.432, 0.132]} b={[-0.012, 1.418, 0.126]} radius={0.0065} kind="skin" />
      <Limb a={[-0.048, 1.458, 0.114]} b={[-0.03, 1.436, 0.12]} radius={0.007} kind="skin" />
      <Limb a={[-0.042, 1.458, 0.148]} b={[-0.02, 1.44, 0.158]} radius={0.008} kind="skin" />
      <mesh position={[0.19, 0.748, 0.085]} scale={[0.8, 1, 0.62]}>
        <sphereGeometry args={[0.024, 12, 10]} />
        <Mat kind="skin" />
      </mesh>
      <Limb a={CUFF_L} b={[0.19, 0.75, 0.08]} radius={0.018} kind="skin" />
      <Limb a={[0.19, 0.73, 0.09]} b={[0.175, 0.69, 0.1]} radius={0.008} kind="skin" />
      <Limb a={[0.175, 0.732, 0.078]} b={[0.165, 0.695, 0.084]} radius={0.007} kind="skin" />
    </group>
  );
}

function Shorts() {
  return (
    <group name="shorts">
      <mesh position={[0, 0.8, 0.01]}>
        <sphereGeometry args={[0.07, 16, 12]} />
        <Mat kind="skin" />
      </mesh>
      <RoundedBox args={[0.3, 0.16, 0.18]} radius={0.04} smoothness={4} position={[0, 0.885, 0.016]}>
        <Mat kind="shorts" />
      </RoundedBox>
      <mesh position={[0.072, 0.78, 0.02]}>
        <cylinderGeometry args={[0.072, 0.062, 0.12, 16]} />
        <Mat kind="shorts" />
      </mesh>
      <mesh position={[-0.072, 0.78, 0.02]}>
        <cylinderGeometry args={[0.072, 0.062, 0.12, 16]} />
        <Mat kind="shorts" />
      </mesh>
      <mesh position={[0, 0.955, 0.02]} rotation={[0.12, 0, 0]}>
        <torusGeometry args={[0.128, 0.015, 8, 22]} />
        <Mat kind="shortsBand" />
      </mesh>
      <group position={[0.1, 0.83, 0.1]} rotation={[0.2, 0.15, 0]} name="shorts-mark">
        <mesh rotation={[0, 0, Math.PI / 4]}>
          <boxGeometry args={[0.03, 0.005, 0.004]} />
          <Mat kind="mark" />
        </mesh>
        <mesh rotation={[0, 0, -Math.PI / 4]}>
          <boxGeometry args={[0.03, 0.005, 0.004]} />
          <Mat kind="mark" />
        </mesh>
      </group>
      <mesh geometry={DRAW_A} name="drawstring-a">
        <Mat kind="mark" />
      </mesh>
      <mesh geometry={DRAW_B} name="drawstring-b">
        <Mat kind="mark" />
      </mesh>
    </group>
  );
}

function LegWarmer({ side, map }: { side: 1 | -1; map: THREE.Texture | null }) {
  return (
    <group position={[side * 0.07, 0.23, 0.02]} name={side < 0 ? "warmer-r" : "warmer-l"}>
      <mesh>
        <cylinderGeometry args={[0.05, 0.046, 0.2, 16]} />
        <Mat kind="knit" map={map} />
      </mesh>
      {Array.from({ length: 8 }, (_, i) => (
        <mesh
          key={i}
          position={[Math.sin(i * 1.4) * 0.004, -0.09 + i * 0.026, Math.cos(i * 0.9) * 0.003]}
          rotation={[Math.PI / 2, 0, i * 0.25]}
        >
          <torusGeometry args={[0.05 + Math.sin(i * 1.7) * 0.007, 0.012, 6, 14]} />
          <Mat kind="knit" map={map} />
        </mesh>
      ))}
      {side < 0 ? (
        <group position={[0.01, 0.07, 0.05]} rotation={[0.5, 0, 0]}>
          <mesh>
            <boxGeometry args={[0.046, 0.011, 0.016]} />
            <Mat kind="metal" />
          </mesh>
          <mesh position={[0.02, 0, 0.008]}>
            <boxGeometry args={[0.01, 0.011, 0.008]} />
            <Mat kind="metal" />
          </mesh>
        </group>
      ) : null}
    </group>
  );
}

function Legs() {
  const rib = useRibMap();
  return (
    <group name="legs">
      <Limb a={HIP_L} b={KNEE_L} radius={0.055} kind="skin" detail="high" />
      <Limb a={HIP_R} b={KNEE_R} radius={0.055} kind="skin" detail="high" />
      <Limb a={KNEE_L} b={ANK_L} radius={0.04} kind="skin" detail="high" />
      <Limb a={KNEE_R} b={ANK_R} radius={0.04} kind="skin" detail="high" />
      <mesh position={KNEE_L}>
        <sphereGeometry args={[0.048, 16, 12]} />
        <Mat kind="skin" />
      </mesh>
      <mesh position={KNEE_R}>
        <sphereGeometry args={[0.048, 16, 12]} />
        <Mat kind="skin" />
      </mesh>
      <LegWarmer side={1} map={rib} />
      <LegWarmer side={-1} map={rib} />
    </group>
  );
}

function Shoe({ side }: { side: 1 | -1 }) {
  return (
    <group position={[side * 0.07, 0, 0.02]} rotation={[0, side * 0.12, 0]} name={side < 0 ? "shoe-r" : "shoe-l"}>
      <RoundedBox args={[0.1, 0.032, 0.21]} radius={0.012} smoothness={3} position={[0, 0.018, 0.01]}>
        <Mat kind="shoe" />
      </RoundedBox>
      <RoundedBox args={[0.09, 0.02, 0.19]} radius={0.008} smoothness={2} position={[0, 0.04, 0.008]}>
        <Mat kind="shoe" />
      </RoundedBox>
      <RoundedBox args={[0.082, 0.046, 0.13]} radius={0.016} smoothness={3} position={[0, 0.068, 0.012]}>
        <Mat kind="shoe" />
      </RoundedBox>
      <mesh position={[0, 0.07, 0.082]} scale={[0.9, 0.68, 1.05]}>
        <sphereGeometry args={[0.04, 16, 12]} />
        <Mat kind="shoe" />
      </mesh>
      <mesh position={[0, 0.095, -0.02]} rotation={[0.3, 0, 0]}>
        <cylinderGeometry args={[0.038, 0.044, 0.04, 16]} />
        <Mat kind="shoe" />
      </mesh>
      {[0, 1, 2, 3].map((i) => (
        <mesh key={i} position={[0, 0.092, 0.012 + i * 0.016]}>
          <boxGeometry args={[0.044, 0.005, 0.007]} />
          <Mat kind="lace" />
        </mesh>
      ))}
    </group>
  );
}

function Jewelry() {
  return (
    <group name="necklace">
      <mesh geometry={CHAIN}>
        <Mat kind="metal" />
      </mesh>
      <group position={[0, 1.168, 0.138]}>
        <mesh>
          <boxGeometry args={[0.01, 0.046, 0.006]} />
          <Mat kind="metal" />
        </mesh>
        <mesh position={[0, 0.006, 0]}>
          <boxGeometry args={[0.028, 0.01, 0.006]} />
          <Mat kind="metal" />
        </mesh>
      </group>
    </group>
  );
}

const Figure = forwardRef<THREE.Group>(function Figure(_props, ref) {
  const local = useRef<THREE.Group>(null);
  const forwarded = useRef<Ref<THREE.Group>>(ref);
  forwarded.current = ref;
  const { alive } = useContext(FigureContext);
  const aliveRef = useRef(alive);
  aliveRef.current = alive;

  const setNode = useCallback((node: THREE.Group | null) => {
    local.current = node;
    const current = forwarded.current;
    if (typeof current === "function") current(node);
    else if (current) current.current = node;
  }, []);

  useFrame((state) => {
    const g = local.current;
    if (!g) return;
    if (!aliveRef.current) {
      g.position.y = 0;
      return;
    }
    g.position.y = Math.sin(state.clock.elapsedTime * 1.2) * 0.005;
  });

  return (
    <group ref={setNode} name="sepaku">
      <Torso />
      <Hoodie />
      <Hands />
      <Shorts />
      <Legs />
      <Shoe side={1} />
      <Shoe side={-1} />
      <Head />
      <Jewelry />
      {RIBBONS.map((geo, i) => (
        <mesh key={i} geometry={geo} name={`ribbon-${i}`}>
          <Mat kind="ribbon" />
        </mesh>
      ))}
    </group>
  );
});

export const Doll = forwardRef<THREE.Group, { wire: boolean; alive: boolean }>(function Doll(
  { wire, alive },
  ref,
) {
  const value = useMemo(() => ({ wire, alive }), [wire, alive]);
  return (
    <FigureContext.Provider value={value}>
      <Figure ref={ref} />
    </FigureContext.Provider>
  );
});
