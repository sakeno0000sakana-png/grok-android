export type ViewId = "full" | "three" | "face" | "feet";
export type Lighting = "studio" | "drama";
