import { forwardRef, useImperativeHandle, useLayoutEffect, useRef, type RefObject } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import * as THREE from "three";
import { Doll } from "@/components/studio/doll";
import type { Lighting, ViewId } from "@/components/studio/types";

const STUDIO = "#c0c1c4";
const DRAMA = "#1c1a22";

const VIEWS: Record<ViewId, { pos: readonly [number, number, number]; target: readonly [number, number, number] }> =
  {
    full: { pos: [0.22, 1.02, 3.55], target: [0, 0.86, 0] },
    three: { pos: [1.5, 1.2, 2.2], target: [0, 0.94, 0] },
    face: { pos: [0.18, 1.58, 0.78], target: [0, 1.5, 0.04] },
    feet: { pos: [0.45, 0.5, 1.15], target: [0, 0.22, 0.05] },
  };

type OrbitHandle = {
  target: THREE.Vector3;
  enabled: boolean;
  update: () => void;
};

export type ViewerHandle = {
  exportGlb: () => Promise<void>;
};

type ViewerProps = {
  view: ViewId;
  lighting: Lighting;
  wire: boolean;
  alive: boolean;
  autoRotate: boolean;
};

function Lights({ lighting }: { lighting: Lighting }) {
  const drama = lighting === "drama";
  return (
    <>
      <ambientLight intensity={drama ? 0.24 : 0.58} />
      <hemisphereLight
        color={drama ? "#ffd2b0" : "#f4f2ef"}
        groundColor={drama ? "#3a3548" : "#b5b6b9"}
        intensity={drama ? 0.4 : 0.5}
      />
      <directionalLight
        position={[1.7, 3.5, 2.5]}
        intensity={drama ? 2.5 : 1.6}
        color={drama ? "#ffc094" : "#fff6ef"}
      />
      <directionalLight
        position={[-2.3, 1.7, 1.9]}
        intensity={drama ? 0.4 : 0.72}
        color={drama ? "#9db7ff" : "#e6eef8"}
      />
      <directionalLight
        position={[0.1, 2.3, -2.5]}
        intensity={drama ? 1.45 : 0.42}
        color={drama ? "#d5e4ff" : "#ffffff"}
      />
    </>
  );
}

function CameraRig({
  view,
  controlsRef,
}: {
  view: ViewId;
  controlsRef: RefObject<OrbitHandle | null>;
}) {
  const fromPos = useRef(new THREE.Vector3());
  const fromTgt = useRef(new THREE.Vector3());
  const tmpPos = useRef(new THREE.Vector3());
  const tmpTgt = useRef(new THREE.Vector3());
  const t = useRef(1);
  const last = useRef(view);

  useFrame((state, delta) => {
    const controls = controlsRef.current;
    if (!controls) return;
    if (last.current !== view) {
      last.current = view;
      fromPos.current.copy(state.camera.position);
      fromTgt.current.copy(controls.target);
      t.current = 0;
      controls.enabled = false;
    }
    if (t.current >= 1) return;
    const step = Math.min(delta, 0.05) / 0.65;
    t.current = Math.min(1, t.current + step);
    const k = 1 - (1 - t.current) ** 3;
    const dest = VIEWS[view];
    tmpPos.current.set(dest.pos[0], dest.pos[1], dest.pos[2]);
    tmpTgt.current.set(dest.target[0], dest.target[1], dest.target[2]);
    state.camera.position.lerpVectors(fromPos.current, tmpPos.current, k);
    controls.target.lerpVectors(fromTgt.current, tmpTgt.current, k);
    state.camera.lookAt(controls.target);
    if (t.current >= 1) {
      controls.enabled = true;
      controls.update();
    }
  });

  return null;
}

function Stage({
  view,
  lighting,
  wire,
  alive,
  autoRotate,
  dollRef,
}: ViewerProps & { dollRef: RefObject<THREE.Group | null> }) {
  const controlsRef = useRef<OrbitHandle>(null);
  const full = VIEWS.full;

  useLayoutEffect(() => {
    const controls = controlsRef.current;
    if (!controls) return;
    controls.target.set(full.target[0], full.target[1], full.target[2]);
    controls.update();
  }, [full.target]);

  const drama = lighting === "drama";
  const bg = drama ? DRAMA : STUDIO;

  return (
    <>
      <color attach="background" args={[bg]} />
      <fog attach="fog" args={[bg, 7, 16]} />
      <Lights lighting={lighting} />
      <Doll ref={dollRef} wire={wire} alive={alive} />
      <ContactShadows
        position={[0, 0.001, 0]}
        opacity={drama ? 0.55 : 0.34}
        scale={4.2}
        blur={2.5}
        far={1.7}
        color={drama ? "#05040a" : "#6a6b70"}
      />
      <OrbitControls
        ref={controlsRef as never}
        enablePan={false}
        enableDamping
        dampingFactor={0.08}
        autoRotate={autoRotate}
        autoRotateSpeed={0.7}
        minDistance={0.5}
        maxDistance={8}
        minPolarAngle={0.18}
        maxPolarAngle={Math.PI / 2.02}
        rotateSpeed={0.85}
      />
      <CameraRig view={view} controlsRef={controlsRef} />
    </>
  );
}

export const Viewer = forwardRef<ViewerHandle, ViewerProps>(function Viewer(props, ref) {
  const dollRef = useRef<THREE.Group>(null);
  const full = VIEWS.full;

  useImperativeHandle(ref, () => ({
    async exportGlb() {
      const doll = dollRef.current;
      if (!doll) throw new Error("model missing");
      const exporter = new GLTFExporter();
      const data = await exporter.parseAsync(doll, { binary: true });
      if (!(data instanceof ArrayBuffer)) throw new Error("export failed");
      const blob = new Blob([data], { type: "model/gltf-binary" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "sepaku.glb";
      a.click();
      URL.revokeObjectURL(url);
    },
  }));

  return (
    <div className="absolute inset-0 touch-none">
      <Canvas
        camera={{ position: [full.pos[0], full.pos[1], full.pos[2]], fov: 30, near: 0.08, far: 40 }}
        dpr={[1, 1.75]}
        gl={{ antialias: true, alpha: false }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping;
          gl.toneMappingExposure = 1.05;
        }}
      >
        <Stage {...props} dollRef={dollRef} />
      </Canvas>
    </div>
  );
});
