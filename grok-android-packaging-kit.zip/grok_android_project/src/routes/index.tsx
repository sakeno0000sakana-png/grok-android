import { useEffect, useRef, useState } from "react";
import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import reference from "@/assets/reference.jpg";
import { Viewer, type ViewerHandle } from "@/components/studio/viewer";
import type { Lighting, ViewId } from "@/components/studio/types";

export const Route = createFileRoute("/")({ component: Home });

const VIEWS: { id: ViewId; label: string }[] = [
  { id: "full", label: "全身" },
  { id: "three", label: "斜め" },
  { id: "face", label: "顔" },
  { id: "feet", label: "足元" },
];

function useAlive() {
  const [alive, setAlive] = useState(true);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setAlive(!mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  return alive;
}

function Chip({
  pressed,
  onClick,
  children,
}: {
  pressed?: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={
        "h-11 rounded-full px-4 text-sm font-medium transition-colors " +
        (pressed ? "bg-fg text-surface" : "bg-surface text-fg")
      }
    >
      {children}
    </button>
  );
}

function Home() {
  const viewerRef = useRef<ViewerHandle>(null);
  const alive = useAlive();
  const [view, setView] = useState<ViewId>("full");
  const [lighting, setLighting] = useState<Lighting>("studio");
  const [wire, setWire] = useState(false);
  const [spin, setSpin] = useState(false);
  const [zoom, setZoom] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "done" | "error">("idle");

  useEffect(() => {
    if (!zoom) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setZoom(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [zoom]);

  async function onSave() {
    if (!viewerRef.current) {
      setSaveState("error");
      return;
    }
    setSaveState("saving");
    try {
      await viewerRef.current.exportGlb();
      setSaveState("done");
    } catch {
      setSaveState("error");
    }
  }

  return (
    <main className="flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <header className="flex shrink-0 items-start justify-between gap-4 px-5 py-4">
        <div>
          <p className="text-xs font-medium tracking-widest text-accent">STUDIO FIGURE</p>
          <h1 className="mt-1 font-display text-4xl leading-none font-medium">雪白</h1>
          <p className="mt-2 max-w-xs text-sm text-pretty text-muted">
            参考画像から組み立てた3Dモデル
          </p>
        </div>
        <button
          type="button"
          onClick={() => setZoom(true)}
          className="flex h-11 shrink-0 items-center gap-2 rounded-full bg-surface pr-4 pl-2 text-sm font-medium"
        >
          <img src={reference} alt="" className="size-8 rounded-full object-cover" />
          参考画像
        </button>
      </header>

      <div className="relative min-h-0 flex-1">
        <ClientOnly
          fallback={
            <div className="absolute inset-0 grid place-items-center text-sm text-muted">
              モデルを組んでいます
            </div>
          }
        >
          <Viewer
            ref={viewerRef}
            view={view}
            lighting={lighting}
            wire={wire}
            alive={alive}
            autoRotate={spin && alive}
          />
        </ClientOnly>
      </div>

      <footer className="shrink-0 px-4 pt-3 pb-4">
        <div className="mx-auto flex max-w-3xl flex-wrap justify-center gap-2">
          {VIEWS.map((item) => (
            <Chip key={item.id} pressed={view === item.id} onClick={() => setView(item.id)}>
              {item.label}
            </Chip>
          ))}
          <Chip pressed={spin} onClick={() => setSpin((v) => !v)}>
            回転
          </Chip>
          <Chip pressed={wire} onClick={() => setWire((v) => !v)}>
            線画
          </Chip>
          <Chip pressed={lighting === "studio"} onClick={() => setLighting("studio")}>
            スタジオ
          </Chip>
          <Chip pressed={lighting === "drama"} onClick={() => setLighting("drama")}>
            ドラマ
          </Chip>
          <Chip pressed={false} onClick={() => void onSave()}>
            {saveState === "saving" ? "保存中" : "保存"}
          </Chip>
        </div>
        <p className="mt-3 text-center text-sm text-pretty text-muted">
          {saveState === "done"
            ? "sepaku.glb を保存しました"
            : saveState === "error"
              ? "保存できませんでした。もう一度試してください"
              : "ドラッグで回す · ピンチかスクロールで寄る"}
        </p>
      </footer>

      {zoom ? (
        <div
          className="absolute inset-0 z-30 flex items-center justify-center bg-fg/60 p-6"
          role="dialog"
          aria-modal="true"
          aria-label="参考画像"
          onClick={() => setZoom(false)}
        >
          <button
            type="button"
            className="absolute top-4 right-4 h-11 rounded-full bg-surface px-4 text-sm font-medium text-fg"
            onClick={(event) => {
              event.stopPropagation();
              setZoom(false);
            }}
          >
            閉じる
          </button>
          <img
            src={reference}
            alt="元にしたキャラクターの参考画像"
            className="max-h-full max-w-full rounded-2xl"
            onClick={(event) => event.stopPropagation()}
          />
        </div>
      ) : null}
    </main>
  );
}
